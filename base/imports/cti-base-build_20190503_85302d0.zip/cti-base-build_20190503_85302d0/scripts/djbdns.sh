#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

sudo cp $1/djbdns-1.05.tar.gz /usr/local/src/
cd /usr/local/src
sudo tar -zxvf djbdns-1.05.tar.gz
cd djbdns-1.05
sudo mv conf-cc conf-cc.orig
sudo cp $2/conf-cc.djbdns conf-cc
sudo make
sudo make setup check