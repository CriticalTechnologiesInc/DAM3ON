#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

for user in $@
do
	sudo adduser $user
	cd /home/$user
	sudo mkdir Downloads
	sudo mkdir .ssh
	sudo chown -R $user.$user Downloads
	sudo chown -R $user.$user .ssh
	sudo usermod -aG sudo $user
done