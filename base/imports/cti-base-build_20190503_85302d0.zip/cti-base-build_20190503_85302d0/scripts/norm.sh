#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

sudo cp $1/src-norm-1.5.8.tgz /usr/local/src/
cd /usr/local/src/
sudo tar -zxvf src-norm-1.5.8.tgz
cd /usr/local/src/norm-1.5.8/protolib/makefiles
sudo cp Makefile.linux Makefile
sudo make
sudo cp libprotokit.a /usr/local/lib/		
cd /usr/local/src/norm-1.5.8/makefiles
sudo cp Makefile.linux Makefile
sudo make
sudo cp libnorm.a /usr/local/lib/