#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

# move premade files to locations
sudo cp $1/rc-local.service /etc/systemd/system/
sudo cp $1/rc.local /etc/

# fix permissions and setup service
sudo chmod a+x /etc/rc.local
sudo systemctl enable rc-local
sudo systemctl start rc-local.service
sudo systemctl status rc-local.service
