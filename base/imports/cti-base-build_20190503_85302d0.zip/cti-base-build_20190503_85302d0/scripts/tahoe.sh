#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

sudo cp $1/tahoe-lafs-1.13.0.tar.bz2 /usr/local/src/
sudo cp $1/get-pip.py /usr/local/bin
cd /usr/local/bin
sudo -H python get-pip.py
pip --version
virtualenv --version
cd /usr/local/src/
sudo tar -jxvf tahoe-lafs-1.13.0.tar.bz2
cd tahoe-lafs-1.13.0
sudo virtualenv venv
sudo -H venv/bin/pip install .
sudo ln -s /usr/local/src/tahoe-lafs-1.13.0/venv/bin/tahoe /usr/local/bin/tahoe
