#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

sudo cp $1/dhcp-4.4.1.tar.gz /usr/local/src/
cd /usr/local/src
sudo tar -zxvf dhcp-4.4.1.tar.gz
cd dhcp-4.4.1
sudo ./configure
sudo make
sudo make install