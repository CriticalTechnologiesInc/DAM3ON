#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

# Updating/Upgrades
sudo apt update -y
sudo apt upgrade -y
sudo apt dist-upgrade -y

# Base Build Dependencies
sudo apt install -y build-essential python-dev
sudo apt install -y libssl-dev python-virtualenv
sudo apt install -y libnetfilter-queue-dev libxml2-dev
sudo apt install -y lzma lzma-dev liblzma-dev
sudo apt install -y dos2unix lm-sensors
sudo apt install -y zip unzip

# Removing stuff not needed
sudo apt remove -y unattended-upgrades
sudo apt autoremove -y

# Turning off stuff not needed
sudo systemctl stop apt-daily.timer
sudo systemctl disable apt-daily.timer
sudo systemctl disable apt-daily.service
sudo systemctl daemon-reload
