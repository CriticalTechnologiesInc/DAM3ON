#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

# bison
sudo apt install -y bison

# flex
sudo cp $1/flex-2.6.0.tar.bz2 /usr/local/src/
cd /usr/local/src
sudo tar -jxvf flex-2.6.0.tar.bz2
cd flex-2.6.0
sudo ./configure
sudo make
sudo make install

# libpcap
sudo cp $1/libpcap-1.9.0.tar.gz /usr/local/src/
cd /usr/local/src/
sudo tar -zxvf libpcap-1.9.0.tar.gz
cd libpcap-1.9.0
sudo ./configure
sudo make
sudo make install

# tcpdump
sudo cp $1/tcpdump-4.9.2.tar.gz /usr/local/src/
cd /usr/local/src/
sudo tar -zxvf tcpdump-4.9.2.tar.gz
cd tcpdump-4.9.2
sudo ./configure
sudo make
sudo make install
