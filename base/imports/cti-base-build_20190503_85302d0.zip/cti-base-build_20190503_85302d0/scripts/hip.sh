#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# 2019-05-02

sudo cp $1/cti-openhip-_* /usr/local/src/
cd /usr/local/src
sudo unzip cti-openhip_*.zip
cd cti-openhip_*
sudo ./install.sh