#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

sudo apt update
sudo apt install software-properties-common
sudo add-apt-repository universe
sudo add-apt-repository ppa:certbot/certbot
sudo apt update
sudo apt install -y certbot python-certbot-apache 
cd /etc/apache2/sites-available
sudo cp 000-default.conf 000-default.conf.preLE
sudo cp default-ssl.conf default-ssl.conf.preLE
# cd
# sudo certbot --apache