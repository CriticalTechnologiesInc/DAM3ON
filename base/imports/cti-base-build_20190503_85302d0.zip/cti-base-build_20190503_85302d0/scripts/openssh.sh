#!/bin/bash

# Critical Technologies Inc. (CTI)
# Adam Wiethuechter <adam.wiethuechter@critical.com>
# April 21, 2019

# zlib upgrade
sudo cp $1/zlib-1.2.11.tar.gz /usr/local/src/
cd /usr/local/src/
sudo tar -zxvf zlib-1.2.11.tar.gz
cd zlib-1.2.11/
sudo ./configure
sudo make test
sudo make install

# openssh upgrade
sudo cp $1/openssh-7.9p1.tar.gz /usr/local/src
cd /usr/local/src
sudo tar -zxvf openssh-7.9p1.tar.gz
cd openssh-7.9p1
sudo ./configure
sudo make
sudo make install

# This must be done manually?!!?
# create the fingerprints
# cd /etc/ssh
# for keyType in 'ecdsa rsa ed25519'
# do
# 	sudo mkdir $(keyType)fingerprint
#	cd $(keyType)fingerprint
#	ssh-keygen –E md5 –lf ../ssh_host_$(keyType)_key.pub > fp.txt
# done

# move configuration file
cd /etc/ssh
sudo mv sshd_config sshd_config.orig
sudo cp $2/sshd_config .

sudo service ssh restart