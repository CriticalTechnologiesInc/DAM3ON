/*
 * Create a quote.
 * Copyright (C) 2010 The MITRE Corporation
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the BSD License as published by the
 * University of California.
 */

#if defined HAVE_CONFIG_H
#include "config.h"
#endif
#include <tss/tspi.h>
#include <stddef.h>
#include <stdlib.h>
#include "tpm_quote.h"

#if defined HAVE_OPENSSL_UI_H && defined HAVE_OPENSSL_UI_LIB
#define USE_OPENSSL_UI
#endif

#if defined USE_OPENSSL_UI
#include <openssl/ui.h>

#define UI_MAX_SECRET_STRING_LENGTH 256

/* Prompt for a password using OpenSSL's UI library */
static int getpasswd(const char *prompt, char *buf, int len)
{
  UI *ui = UI_new();		/* Create UI with default method */
  if (!ui)
    return -1;

  /* Add input buffer leaving room for a null byte */
  if (!UI_add_input_string(ui, prompt, 0, buf, 1, len - 1)) {
    UI_free(ui);
    return -1;
  }

  int rc = UI_process(ui);	/* Print prompt and read password */
  UI_free(ui);
  return rc ? -1 : 0;
}
#endif

/* This function shows the hash offset when one is handling quotes in
   blob format. */
// #define SHOW_HASH_OFFSET
#if defined SHOW_HASH_OFFSET && defined HAVE_TROUSERS_TROUSERS_H
#include <stdio.h>
#include <trousers/trousers.h>
static void show_hash_offset(TSS_VALIDATION *valid)
{
  if (!valid)
    return;
  TPM_QUOTE_INFO2 *qi2 = (TPM_QUOTE_INFO2 *)(valid->rgbData);
  fprintf(stderr, "TAG: %c%c%c%c\n", qi2->fixed[0],
	  qi2->fixed[1],qi2->fixed[2],qi2->fixed[3]);
  if (qi2->fixed[0] != 'Q' || qi2->fixed[1] != 'U' ||
      qi2->fixed[2] != 'T' || qi2->fixed[3] != '2')
    return;
  fprintf(stderr, "Data size %d\n", valid->ulDataLength);
  UINT64 offset = (UINT64)offsetof(TPM_QUOTE_INFO2, externalData);
  fprintf(stderr, "Nonce start %lu\n", offset);
  Trspi_UnloadBlob_NONCE(&offset, valid->rgbData, 0);
  fprintf(stderr, "Unload PCR_INFO_SHORT start %lu\n", offset);
  TPM_PCR_INFO_SHORT info;
  TSS_RESULT rc =
    Trspi_UnloadBlob_PCR_INFO_SHORT(&offset, valid->rgbData, &info);
  fprintf(stderr, "Unload PCR_INFO_SHORT return code %d offset %lu\n",
	  rc, offset);
  fprintf(stderr, "Locality at release %d\n", info.localityAtRelease);
}
#endif

/* Returns a TPM quote in the TSS validation struct.  The nonce used
   by the quote is passed in via the struct. */
int quote(TSS_HCONTEXT hContext, TSS_UUID uuid,
	  UINT32 *pcrs, UINT32 npcrs,
	  TSS_VALIDATION *valid)
{
  /* Get SRK */
  TSS_UUID SRK_UUID = TSS_UUID_SRK;
  TSS_HKEY hSRK;
  TSS_RESULT rc;
  rc = Tspi_Context_LoadKeyByUUID(hContext, TSS_PS_TYPE_SYSTEM,
				  SRK_UUID, &hSRK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading SRK");

  TSS_HPOLICY hSrkPolicy;
  rc = Tspi_GetPolicyObject(hSRK, TSS_POLICY_USAGE, &hSrkPolicy);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "getting SRK policy");

// new code
///////////

#if defined USE_OPENSSL_UI
    
	// doesn't support unicode 
      int bufSize_tmp = UI_MAX_SECRET_STRING_LENGTH;
      char buf_tmp[bufSize_tmp];
      if (getpasswd("Enter SRK password: ", buf_tmp, bufSize_tmp) < 0)
		return tss_err(TSS_E_FAIL, "getting SRK password");

      rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_PLAIN, strlen(buf_tmp), (BYTE *)buf_tmp);

      memset(buf_tmp, 0, bufSize_tmp);
#else
    rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_POPUP, 0, NULL);
#endif

//////////
				 
	
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "setting SRK secret");

  TSS_HKEY hAIK;		/* AIK handle */
  rc = Tspi_Context_LoadKeyByUUID(hContext, TSS_PS_TYPE_SYSTEM,
				  uuid, &hAIK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading AIK");

  TSS_HPCRS hPCRs;
#if !defined HAVE_TSS_12_LIB
  rc = Tspi_Context_CreateObject(hContext, TSS_OBJECT_TYPE_PCRS,
				 TSS_PCRS_STRUCT_INFO, &hPCRs);
#else
  rc = Tspi_Context_CreateObject(hContext, TSS_OBJECT_TYPE_PCRS,
				 TSS_PCRS_STRUCT_INFO_SHORT, &hPCRs);
#endif
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "creating PCR mask object");

  UINT32 i;
  for (i = 0; i < npcrs; i++) {
#if !defined HAVE_TSS_12_LIB
    rc = Tspi_PcrComposite_SelectPcrIndex(hPCRs, pcrs[i]);
#else
    rc = Tspi_PcrComposite_SelectPcrIndexEx(hPCRs, pcrs[i],
					    TSS_PCRS_DIRECTION_RELEASE);
#endif
    if (rc != TSS_SUCCESS)
      return tss_err(rc, "creating PCR mask");
  }

  /* Get TPM handle */
  TSS_HTPM hTPM;		/* TPM handle */
  rc = Tspi_Context_GetTpmObject(hContext, &hTPM);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "getting TPM object");

  /* Perform Quote */
#if !defined HAVE_TSS_12_LIB
  rc = Tspi_TPM_Quote(hTPM, hAIK, hPCRs, valid);
#else
  BYTE *versionInfo;
  UINT32 versionInfoLen;
  rc = Tspi_TPM_Quote2(hTPM, hAIK, FALSE, hPCRs, valid,
		       &versionInfoLen, &versionInfo);
#if defined SHOW_HASH_OFFSET && defined HAVE_TROUSERS_TROUSERS_H
  show_hash_offset(valid);
#endif
#endif
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "performing quote");

  return 0;
}

/* Returns a TPM quote in the TSS validation struct.  The nonce used
   by the quote is passed in via the struct. */
int quote_new(TSS_HCONTEXT hContext, TSS_UUID uuid,
	  UINT32 *pcrs, UINT32 npcrs,
	  TSS_VALIDATION *valid, int use_well_known, const char *password)
{
  /* Get SRK */
  TSS_UUID SRK_UUID = TSS_UUID_SRK;
  TSS_HKEY hSRK;
  TSS_RESULT rc;
  rc = Tspi_Context_LoadKeyByUUID(hContext, TSS_PS_TYPE_SYSTEM,
				  SRK_UUID, &hSRK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading SRK");

  TSS_HPOLICY hSrkPolicy;
  rc = Tspi_GetPolicyObject(hSRK, TSS_POLICY_USAGE, &hSrkPolicy);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "getting SRK policy");

// new code
///////////
if(use_well_known == 1){
	// This was the old code
	BYTE srkSecret[] = TSS_WELL_KNOWN_SECRET;
  rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_SHA1,
			     sizeof srkSecret, srkSecret);
}else if(password == NULL){
					 
#if defined USE_OPENSSL_UI
    
	// doesn't support unicode 
      int bufSize_tmp = UI_MAX_SECRET_STRING_LENGTH;
      char buf_tmp[bufSize_tmp];
      if (getpasswd("Enter SRK password: ", buf_tmp, bufSize_tmp) < 0)
		return tss_err(TSS_E_FAIL, "getting SRK password");

      rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_PLAIN, strlen(buf_tmp), (BYTE *)buf_tmp);

      memset(buf_tmp, 0, bufSize_tmp);
#else
    rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_POPUP, 0, NULL);
#endif
				 
}else{
	rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_PLAIN, strlen(password), (BYTE *)password);
	memset(password, 0, strlen(password));
}
//////////
				 
	
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "setting SRK secret");

  TSS_HKEY hAIK;		/* AIK handle */
  rc = Tspi_Context_LoadKeyByUUID(hContext, TSS_PS_TYPE_SYSTEM,
				  uuid, &hAIK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading AIK");

  TSS_HPCRS hPCRs;
#if !defined HAVE_TSS_12_LIB
  rc = Tspi_Context_CreateObject(hContext, TSS_OBJECT_TYPE_PCRS,
				 TSS_PCRS_STRUCT_INFO, &hPCRs);
#else
  rc = Tspi_Context_CreateObject(hContext, TSS_OBJECT_TYPE_PCRS,
				 TSS_PCRS_STRUCT_INFO_SHORT, &hPCRs);
#endif
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "creating PCR mask object");

  UINT32 i;
  for (i = 0; i < npcrs; i++) {
#if !defined HAVE_TSS_12_LIB
    rc = Tspi_PcrComposite_SelectPcrIndex(hPCRs, pcrs[i]);
#else
    rc = Tspi_PcrComposite_SelectPcrIndexEx(hPCRs, pcrs[i],
					    TSS_PCRS_DIRECTION_RELEASE);
#endif
    if (rc != TSS_SUCCESS)
      return tss_err(rc, "creating PCR mask");
  }

  /* Get TPM handle */
  TSS_HTPM hTPM;		/* TPM handle */
  rc = Tspi_Context_GetTpmObject(hContext, &hTPM);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "getting TPM object");

  /* Perform Quote */
#if !defined HAVE_TSS_12_LIB
  rc = Tspi_TPM_Quote(hTPM, hAIK, hPCRs, valid);
#else
  BYTE *versionInfo;
  UINT32 versionInfoLen;
  rc = Tspi_TPM_Quote2(hTPM, hAIK, FALSE, hPCRs, valid,
		       &versionInfoLen, &versionInfo);
#if defined SHOW_HASH_OFFSET && defined HAVE_TROUSERS_TROUSERS_H
  show_hash_offset(valid);
#endif
#endif
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "performing quote");

  return 0;
}


