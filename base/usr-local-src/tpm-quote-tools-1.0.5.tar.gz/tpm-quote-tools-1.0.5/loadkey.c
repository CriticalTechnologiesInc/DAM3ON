/*
 * Load a key.
 * Copyright (C) 2010 The MITRE Corporation
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the BSD License as published by the
 * University of California.
 */

#if defined HAVE_CONFIG_H
#include "config.h"
#endif
#include <stddef.h>
#include <stdlib.h>
#include <tss/tspi.h>
#include "tpm_quote.h"

#if defined HAVE_OPENSSL_UI_H && defined HAVE_OPENSSL_UI_LIB
#define USE_OPENSSL_UI
#endif

#if defined USE_OPENSSL_UI
#include <openssl/ui.h>

#define UI_MAX_SECRET_STRING_LENGTH 256

/* Prompt for a password using OpenSSL's UI library */
static int getpasswd(const char *prompt, char *buf, int len)
{
  UI *ui = UI_new();		/* Create UI with default method */
  if (!ui)
    return -1;

  /* Add input buffer leaving room for a null byte */
  if (!UI_add_input_string(ui, prompt, 0, buf, 1, len - 1)) {
    UI_free(ui);
    return -1;
  }

  int rc = UI_process(ui);	/* Print prompt and read password */
  UI_free(ui);
  return rc ? -1 : 0;
}
#endif

/* Load a key and register it under the given UUID. */
int loadkey(TSS_HCONTEXT hContext,
	    BYTE *blob, UINT32 blobLen,
	    TSS_UUID uuid)
{
  /* Get SRK */
  TSS_UUID SRK_UUID = TSS_UUID_SRK;
  TSS_HKEY hSRK;
  TSS_RESULT rc;
  rc = Tspi_Context_LoadKeyByUUID(hContext, TSS_PS_TYPE_SYSTEM,
				  SRK_UUID, &hSRK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading SRK");

  TSS_HPOLICY hSrkPolicy;
  rc = Tspi_GetPolicyObject(hSRK, TSS_POLICY_USAGE, &hSrkPolicy);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "getting SRK policy");

  BYTE srkSecret[] = TSS_WELL_KNOWN_SECRET;
  rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_SHA1,
			     sizeof srkSecret, srkSecret);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "setting SRK secret");

  TSS_HKEY hAIK;		/* AIK handle */
  rc = Tspi_Context_LoadKeyByBlob(hContext, hSRK, blobLen, blob, &hAIK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading key blob");

  /* Register the key in persistant storage */
  rc = Tspi_Context_RegisterKey(hContext, hAIK, TSS_PS_TYPE_SYSTEM,
				uuid, TSS_PS_TYPE_SYSTEM, SRK_UUID);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "registering a key");

  return 0;
}

/* Load a key and register it under the given UUID. */
int loadkey_new(TSS_HCONTEXT hContext,
	    BYTE *blob, UINT32 blobLen,
	    TSS_UUID uuid)
{
  /* Get SRK */
  TSS_UUID SRK_UUID = TSS_UUID_SRK;
  TSS_HKEY hSRK;
  TSS_RESULT rc;
  rc = Tspi_Context_LoadKeyByUUID(hContext, TSS_PS_TYPE_SYSTEM,
				  SRK_UUID, &hSRK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading SRK");

  TSS_HPOLICY hSrkPolicy;
  rc = Tspi_GetPolicyObject(hSRK, TSS_POLICY_USAGE, &hSrkPolicy);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "getting SRK policy");
//////////////

#if defined USE_OPENSSL_UI
    
	// doesn't support unicode 
      int bufSize_tmp = UI_MAX_SECRET_STRING_LENGTH;
      char buf_tmp[bufSize_tmp];
      if (getpasswd("Enter SRK password: ", buf_tmp, bufSize_tmp) < 0)
		return tss_err(TSS_E_FAIL, "getting SRK password");

      rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_PLAIN, strlen(buf_tmp), (BYTE *)buf_tmp);

      memset(buf_tmp, 0, bufSize_tmp);
    
#else
    rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_POPUP, 0, NULL);
#endif

///////////////
/*   BYTE srkSecret[] = TSS_WELL_KNOWN_SECRET;
  rc = Tspi_Policy_SetSecret(hSrkPolicy, TSS_SECRET_MODE_SHA1,
			     sizeof srkSecret, srkSecret); */


 if (rc != TSS_SUCCESS)
    return tss_err(rc, "setting SRK secret");

  TSS_HKEY hAIK;		/* AIK handle */
  rc = Tspi_Context_LoadKeyByBlob(hContext, hSRK, blobLen, blob, &hAIK);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "loading key blob");

  /* Register the key in persistant storage */
  rc = Tspi_Context_RegisterKey(hContext, hAIK, TSS_PS_TYPE_SYSTEM,
				uuid, TSS_PS_TYPE_SYSTEM, SRK_UUID);
  if (rc != TSS_SUCCESS)
    return tss_err(rc, "registering a key");

  return 0;
}

