
#ifndef __TCPA_STRUCT_H__
#define __TCPA_STRUCT_H__

#warning including deprecated header file tcpa_struct.h

#endif
